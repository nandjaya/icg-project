package com.intellij;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        ArrayList<String> ownerName = new ArrayList();
        ArrayList<String> employeeName = new ArrayList();
        ArrayList<String> clientName = new ArrayList();
        ArrayList<String> productName = new ArrayList();
        ArrayList<Double> productPrice = new ArrayList();
        ArrayList<Integer> quantity = new ArrayList();
        ArrayList<Double> ServiceValue = new ArrayList();
        ArrayList<Double> servicePrice = new ArrayList();
        ArrayList<Double> productsValue = new ArrayList();
        ArrayList<Double> productsPrice = new ArrayList();
        ArrayList<String> customerName = new ArrayList();

        String response;

        int counter = 0;

        int input;

        System.out.println("***********Main Menu**************");
        System.out.println("1.Buy Items");
        System.out.println("2.Log In as Admin");
        System.out.println("3.LOGOUT");
        System.out.println("*****************************");
        System.out.println("Enter Number:");
        int selection = in.nextInt();

        switch (selection) {case (1):
                customerMenu();
                break;
            case (2):
                System.out.println("Enter Admin Password:");
                int password = in.nextInt();
                if (password == 2021) {
                    adminMenu();
                }
                break;
            case (3):
                System.out.println("Successfully logout!!");
                break;
            default:
                System.out.println("Invalid selection..!\nPlease try again");
        }

    }

    private static void adminMenu() {
        System.out.println("*********Admin Menu********");
        System.out.println("1.Add Products");
        System.out.println("2.ReturnProducts's Value");
        System.out.println("3.Employee Management");
        System.out.println("4.services Portfolio's Value");
        System.out.println("5.Customer database");
        System.out.println("6.Logout");
        System.out.println("***********************");


        Scanner in = new Scanner(System.in) ;
        int input = in.nextInt();
        switch(input){
            case(1):
                returnProductsValue();
                break;
            case(2):
                returnProductsValue();
                break;
            case(3):
                EmployeeManagement(2);
                break;
            case(4):
                ServiceportfolioValue();
                break;
            case(5):
                customerdatabase();
                break;
            case(6):
                mainMenu();
                break;
            default:
                System.out.println("Invalid input!!");
        }

    }

    private static void mainMenu() {

    }

    private static void returnProductsValue() {
        System.out.println("Products returned has a value of N$ 40000.00");
    }

    private static void EmployeeManagement(int counter) {
        System.out.println("addEmployee\nremoveEmployee");
    }

    private static void ServiceportfolioValue() {
        System.out.println("The value of a Service is N$200.00");
    }

    private static void customerdatabase() {
        System.out.println("addCustomer\nreturnCustomer");
    }


    private static void exit() {
    }

    private static void customerMenu() {
        double tendered;
        System.out.println("=========Products=========");
        System.out.println("Code   Name   Qty   Price");

        System.out.println("===========================");
    }
}
